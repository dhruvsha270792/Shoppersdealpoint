package com.nexusdevs.shoppersdeal.server.db;

public class RedisManager {

}
