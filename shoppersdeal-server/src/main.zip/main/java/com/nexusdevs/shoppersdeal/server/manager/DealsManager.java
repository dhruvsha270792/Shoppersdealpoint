package com.nexusdevs.shoppersdeal.server.manager;

public class DealsManager {

}
