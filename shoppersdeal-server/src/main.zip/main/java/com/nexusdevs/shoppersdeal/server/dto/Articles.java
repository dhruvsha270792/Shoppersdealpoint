package com.nexusdevs.shoppersdeal.server.dto;

public class Articles {

	private Float wei_article;
	private int num_article;

	public Float getWei_article() {
		return wei_article;
	}

	public void setWei_article(Float wei_article) {
		this.wei_article = wei_article;
	}

	public int getNum_article() {
		return num_article;
	}

	public void setNum_article(int num_article) {
		this.num_article = num_article;
	}

}
