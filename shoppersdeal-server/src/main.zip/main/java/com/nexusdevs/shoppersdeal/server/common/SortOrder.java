package com.nexusdevs.shoppersdeal.server.common;

public enum SortOrder {
	ASCENDING, DESCENDING
}
