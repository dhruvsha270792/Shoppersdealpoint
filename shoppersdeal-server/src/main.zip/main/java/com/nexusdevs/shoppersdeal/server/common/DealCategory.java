package com.nexusdevs.shoppersdeal.server.common;

public enum DealCategory {
	normal, topRated, special, hotDeals;
}
