package com.nexusdevs.shoppersdeal.server.common;

public enum AddressType {
	HOME, OFFICE;
}
